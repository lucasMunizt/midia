package br.edu.uni7.tecnicas.springjpa.persistence;

import br.edu.uni7.tecnicas.springjpa.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookRepository  extends JpaRepository<Book, Integer>{


}
