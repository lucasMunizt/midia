package br.edu.uni7.tecnicas.springjpa.web;
import br.edu.uni7.tecnicas.springjpa.entity.Book;
import br.edu.uni7.tecnicas.springjpa.persistence.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("books")
public class BookController {
    @Autowired
    private BookRepository bookRepository;
    @GetMapping(path = "books")
    public ResponseEntity<List<Book>> findAll(){
       ResponseEntity<List<Book>> response = null;
        List<Book> books = bookRepository.findAll();
        if (books == null || books.isEmpty()){
            response = ResponseEntity.noContent().build();
        }else {
            response = ResponseEntity.ok(books);
        }

        return response;
    }
    @PostMapping(path = "savebooks")
    public ResponseEntity<Book> save(String title,String isbn){
        ResponseEntity<Book> response = null;
        try {
            Book book = new Book(null, title, isbn);
            book = bookRepository.save(book);

            if (book.getId() != null) {
                response = new ResponseEntity<Book>(book, HttpStatus.CREATED);
            } else {
                response = ResponseEntity.badRequest().build();
            }
        }catch (Exception e){
            response = ResponseEntity.badRequest().build();
        }
        return response;
    }

//    @GetMapping(path = "books/{id}")
//    public ResponseEntity<Book> findByIsbn(@RequestParam(name = "isbn"))



}
