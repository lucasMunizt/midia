package br.edu.uni7.tecnicas.springjpa.web;

import br.edu.uni7.tecnicas.springjpa.entity.Product;
import br.edu.uni7.tecnicas.springjpa.persistence.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("products")
public class ProductController {
    @Autowired
    private ProductRepository repository;
   // C:\Users\56049952\.m2\repository\org\projectlombok\lombok\1.18.30\lombok-1.18.30.jar
    @PostMapping
    public Product save(@RequestBody String name, String description, Double price){
        Product product = new Product (null, name, description, price);

        repository.save(product);
        return product;
    }

    @GetMapping
    public List<Product> findAll(){
        return repository.findAll();
    }

    @GetMapping(path = "products/byName")
    public Product findByName(@RequestParam(name = "name") String name){
        Product product = null;
        Optional<Product> optional = repository.findByName(name);
        if (optional.isPresent()){
            product = optional.get();
        }
        return product;
    }

//    @GetMapping(path = "products/{id}")
//    public Product findByID(@PathVariable (name = "id")Integer id){
//        Product product = null;
//        Optional<Product> optional  = repository.findById(id);
//        if (optional.isPresent()){
//            product = optional.get();
//        }
//        return product;
//    }
    @PutMapping(path = "/products")
    public Product update(Product product){
        Product fromDb = null;

        Optional<Product> optional = repository.findById(product.getId());
        if(optional.isPresent()){
            fromDb = optional.get();

            if(product.getName() != null){
                fromDb.setName(product.getName());
            }

            if(product.getDescription() != null){
                fromDb.setDescription(product.getDescription());
            }

            if (product.getPrice() != null) {
                fromDb.setPrice(product.getPrice());
            }
            repository.save(fromDb);
        }

        return product;
    }

    @DeleteMapping("/{id}")
    public Product remove(@PathVariable Integer id){
        Product product = null;
        Optional<Product> optional = repository.findById(id);

        if(optional.isPresent()){
            product = optional.get();
            repository.delete(product);
        }
        return product;
    }
}
