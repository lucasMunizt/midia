package com.example.media.Persistence;

import com.example.media.Entity.MediaType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MediaTypeRepository extends JpaRepository<MediaType,Integer> {
}
