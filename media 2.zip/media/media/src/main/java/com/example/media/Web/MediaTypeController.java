package com.example.media.Web;
import com.example.media.Entity.MediaType;
import com.example.media.Entity.Movie;
import com.example.media.Persistence.MidiaTypeRepository;
import com.example.media.dto.Dto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
//@RequestMapping("movies")
public class MediaTypeController {
    @Autowired
    private MidiaTypeRepository midiaTypeRepository;

    @GetMapping(path = "/movies")
    public ResponseEntity<List<Movie>> findAll(){
        ResponseEntity<List<Movie>> response = null;
        List<Movie> movies = midiaTypeRepository.findAll();
        if (movies == null || movies.isEmpty()){
            response = ResponseEntity.noContent().build();
        }else {
            response = ResponseEntity.ok(movies);
        }

        return response;
    }

    @PostMapping(path = "/save")
    public void save(@RequestBody Dto dto){
        System.out.println(dto.nome());
        //mediaTypeRepository.save(dto);
    }

}
