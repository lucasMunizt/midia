package com.example.media.Persistence;

import com.example.media.Entity.MediaType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MidiaTypeRepository extends JpaRepository<MediaType,Integer> {
}
