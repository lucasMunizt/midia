package com.example.media.dto;

public record Dto(String nome) {
}
