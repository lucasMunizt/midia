package com.example.media.Web;
import com.example.media.Persistence.MediaTypeRepository;
import com.example.media.dto.Dto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("movies")
public class MoviesController {
    @Autowired
    private MediaTypeRepository mediaTypeRepository;

    @GetMapping()
    public ResponseEntity read(){
        return ResponseEntity.ok("oi");
    }

    @PostMapping(path = "/save")
    public void save(@RequestBody Dto dto){
        System.out.println(dto.nome());
        //mediaTypeRepository.save(dto);
    }

}
