package com.example.media.Web;

import com.example.media.Persistence.MediaTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("mediatypes")
public class MediaTypeController {
    @Autowired
    private MediaTypeRepository mediaTypeRepository;




}
